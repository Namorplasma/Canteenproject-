from django.shortcuts import render
from django.http import HttpResponse
import qrcode
from io import BytesIO


menu_items = [
    {'id': 1, 'name': 'Burger', 'price': 5.99},
    {'id': 2, 'name': 'Pizza', 'price': 8.99},
]

def menu_view(request):
    context = {
        'menu_items': menu_items,
    }
    return render(request, 'menu/menu.html', context)

def order_view(request, item_id):
    selected_item = None
    for item in menu_items:
        if item['id'] == int(item_id):
            selected_item = item
            break

    if selected_item:
        order_id = f'ORD-{item_id}-{hash(request.session.session_key)}'
        qr_code = generate_qr_code(order_id)

        context = {
            'selected_item': selected_item,
            'order_id': order_id,
            'qr_code': qr_code,
        }
        return render(request, 'menu/order.html', context)
    else:
        return HttpResponse("Item not found")

def order_confirmation_view(request, order_id):
    context = {
        'order_id': order_id,
    }
    return render(request, 'menu/order_confirmation.html', context)

def generate_qr_code(data):
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(data)
    qr.make(fit=True)
    qr_img = qr.make_image(fill_color="black", back_color="white")

    qr_image_io = BytesIO()
    qr_img.save(qr_image_io, format='PNG')
    qr_image_io.seek(0)

    return qr_image_io.read()
