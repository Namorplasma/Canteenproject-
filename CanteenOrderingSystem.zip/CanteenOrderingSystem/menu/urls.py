# menu/urls.py
from django.urls import path
from .views import menu_view, order_view, order_confirmation_view

urlpatterns = [
    path('', menu_view, name='menu'),
    path('order/<int:item_id>/', order_view, name='order'),
    path('order-confirmation/<str:order_id>/', order_confirmation_view, name='order_confirmation'),
]
